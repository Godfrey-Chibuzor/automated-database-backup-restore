--
-- PostgreSQL database dump
--

\restrict KMRfMq7ZrgUjv3n74rn7yPe05aWIrZAmXZ5cSNus7IPYN4NMJgAHF5rPkvIqh0E

-- Dumped from database version 18.4 (Ubuntu 18.4-0ubuntu0.26.04.1)
-- Dumped by pg_dump version 18.4 (Ubuntu 18.4-0ubuntu0.26.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mode_of_transport_q1_2026; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mode_of_transport_q1_2026 (
    id integer NOT NULL,
    mode_of_transport character varying(50) NOT NULL,
    import_billion_naira numeric(15,2) NOT NULL,
    export_billion_naira numeric(15,2) NOT NULL
);


ALTER TABLE public.mode_of_transport_q1_2026 OWNER TO postgres;

--
-- Name: mode_of_transport_q1_2026_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mode_of_transport_q1_2026_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mode_of_transport_q1_2026_id_seq OWNER TO postgres;

--
-- Name: mode_of_transport_q1_2026_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mode_of_transport_q1_2026_id_seq OWNED BY public.mode_of_transport_q1_2026.id;


--
-- Name: top_export_partners_q1_2026; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.top_export_partners_q1_2026 (
    id integer NOT NULL,
    country_of_destination character varying(100) NOT NULL,
    percentage_share_of_total_export numeric(5,2) CONSTRAINT top_export_partners_q1_2026_percentage_share_of_total__not_null NOT NULL
);


ALTER TABLE public.top_export_partners_q1_2026 OWNER TO postgres;

--
-- Name: top_export_partners_q1_2026_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.top_export_partners_q1_2026_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.top_export_partners_q1_2026_id_seq OWNER TO postgres;

--
-- Name: top_export_partners_q1_2026_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.top_export_partners_q1_2026_id_seq OWNED BY public.top_export_partners_q1_2026.id;


--
-- Name: top_import_partners_q1_2026; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.top_import_partners_q1_2026 (
    id integer NOT NULL,
    country_of_origin character varying(100) NOT NULL,
    percentage_share_of_total_import numeric(5,2) CONSTRAINT top_import_partners_q1_2026_percentage_share_of_total__not_null NOT NULL
);


ALTER TABLE public.top_import_partners_q1_2026 OWNER TO postgres;

--
-- Name: top_import_partners_q1_2026_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.top_import_partners_q1_2026_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.top_import_partners_q1_2026_id_seq OWNER TO postgres;

--
-- Name: top_import_partners_q1_2026_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.top_import_partners_q1_2026_id_seq OWNED BY public.top_import_partners_q1_2026.id;


--
-- Name: mode_of_transport_q1_2026 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mode_of_transport_q1_2026 ALTER COLUMN id SET DEFAULT nextval('public.mode_of_transport_q1_2026_id_seq'::regclass);


--
-- Name: top_export_partners_q1_2026 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.top_export_partners_q1_2026 ALTER COLUMN id SET DEFAULT nextval('public.top_export_partners_q1_2026_id_seq'::regclass);


--
-- Name: top_import_partners_q1_2026 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.top_import_partners_q1_2026 ALTER COLUMN id SET DEFAULT nextval('public.top_import_partners_q1_2026_id_seq'::regclass);


--
-- Data for Name: mode_of_transport_q1_2026; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mode_of_transport_q1_2026 (id, mode_of_transport, import_billion_naira, export_billion_naira) FROM stdin;
1	ROAD	44.82	66.39
2	AIR	918.68	81.51
3	MARITIME	12655.83	20971.74
4	OTHER TRANSPORT	0.00	49.63
\.


--
-- Data for Name: top_export_partners_q1_2026; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.top_export_partners_q1_2026 (id, country_of_destination, percentage_share_of_total_export) FROM stdin;
1	INDIA	13.09
2	FRANCE	9.29
3	NETHERLANDS	9.22
4	SPAIN	7.68
5	USA	5.56
\.


--
-- Data for Name: top_import_partners_q1_2026; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.top_import_partners_q1_2026 (id, country_of_origin, percentage_share_of_total_import) FROM stdin;
1	CHINA	37.42
2	USA	20.60
3	GERMANY	2.87
\.


--
-- Name: mode_of_transport_q1_2026_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mode_of_transport_q1_2026_id_seq', 4, true);


--
-- Name: top_export_partners_q1_2026_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.top_export_partners_q1_2026_id_seq', 5, true);


--
-- Name: top_import_partners_q1_2026_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.top_import_partners_q1_2026_id_seq', 3, true);


--
-- Name: mode_of_transport_q1_2026 mode_of_transport_q1_2026_mode_of_transport_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mode_of_transport_q1_2026
    ADD CONSTRAINT mode_of_transport_q1_2026_mode_of_transport_key UNIQUE (mode_of_transport);


--
-- Name: mode_of_transport_q1_2026 mode_of_transport_q1_2026_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mode_of_transport_q1_2026
    ADD CONSTRAINT mode_of_transport_q1_2026_pkey PRIMARY KEY (id);


--
-- Name: top_export_partners_q1_2026 top_export_partners_q1_2026_country_of_destination_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.top_export_partners_q1_2026
    ADD CONSTRAINT top_export_partners_q1_2026_country_of_destination_key UNIQUE (country_of_destination);


--
-- Name: top_export_partners_q1_2026 top_export_partners_q1_2026_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.top_export_partners_q1_2026
    ADD CONSTRAINT top_export_partners_q1_2026_pkey PRIMARY KEY (id);


--
-- Name: top_import_partners_q1_2026 top_import_partners_q1_2026_country_of_origin_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.top_import_partners_q1_2026
    ADD CONSTRAINT top_import_partners_q1_2026_country_of_origin_key UNIQUE (country_of_origin);


--
-- Name: top_import_partners_q1_2026 top_import_partners_q1_2026_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.top_import_partners_q1_2026
    ADD CONSTRAINT top_import_partners_q1_2026_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict KMRfMq7ZrgUjv3n74rn7yPe05aWIrZAmXZ5cSNus7IPYN4NMJgAHF5rPkvIqh0E

